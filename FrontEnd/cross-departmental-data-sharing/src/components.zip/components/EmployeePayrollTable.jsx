// EmployeePayrollTable.jsx
import React, { useState, useEffect } from 'react';
import { Table, Button, Card, CardHeader, Alert } from 'reactstrap';
import { mockEmployees } from './mockEmployees'; 
import PayslipModal from './PayslipModal'; 

// Constants for calculation
const MONTH_DAYS = 30; // Assuming 30 days in the current payroll month
const INCOME_TAX_RATE = 0.03; // 3% of Basic Salary

const EmployeePayrollTable = ({ selectedRole, onBack }) => {
    const [employees, setEmployees] = useState([]);
    const [payrollData, setPayrollData] = useState({});
    const [isCalculated, setIsCalculated] = useState(false);
    
    // State for Payslip Modal
    const [modalOpen, setModalOpen] = useState(false);
    const [selectedEmployeeId, setSelectedEmployeeId] = useState(null);

    useEffect(() => {
        // Load employees for the selected role
        const initialData = mockEmployees[selectedRole] || [];
        setEmployees(initialData);
        // Reset calculation states
        setPayrollData({});
        setIsCalculated(false);
    }, [selectedRole]);

    // Function to perform the full salary calculation for a single employee
    const calculateSalary = (employee) => {
        const lopDays = employee.lopDays || 0;
        const annualSalary = employee.baseSalary;

        // 1. Calculate Monthly Basic Salary
        const monthlyBasicSalary = annualSalary / 12;

        // 2. Calculate LOP Amount
        const dailyRate = monthlyBasicSalary / MONTH_DAYS;
        const lopAmount = lopDays * dailyRate;

        // 3. Calculate Income Tax (3% of Monthly Basic Salary)
        const incomeTaxAmount = monthlyBasicSalary * INCOME_TAX_RATE;

        // 4. Calculate Total Net Amount (Net Salary)
        const netSalary = monthlyBasicSalary - lopAmount - incomeTaxAmount;

        return {
            netSalary: netSalary,
            lopAmount: lopAmount,
            monthlyBasicSalary: monthlyBasicSalary,
            incomeTaxAmount: incomeTaxAmount,
            lops: lopDays,
            MONTH_DAYS: MONTH_DAYS,
            // Format for display immediately after calculation
            salaryDisplay: `₹${netSalary.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",")}`
        };
    };
    
    // Handler for the single "Calculate All Salaries" Button
    const handleCalculateAllClick = () => {
        const newPayrollData = employees.reduce((acc, emp) => {
            acc[emp.empId] = calculateSalary(emp);
            return acc;
        }, {});
        
        setPayrollData(newPayrollData);
        setIsCalculated(true);
    };

    // Modal Handlers
    const toggleModal = () => setModalOpen(!modalOpen);

    const handleGeneratePaySlip = (empId) => {
        if (payrollData[empId]?.netSalary) {
            setSelectedEmployeeId(empId);
            setModalOpen(true);
        }
    };
    
    // Find the currently selected employee and their payroll data for the modal
    const employeeForModal = employees.find(emp => emp.empId === selectedEmployeeId);
    const payrollDataForModal = payrollData[selectedEmployeeId];

    return (
        <div className="fluid p-4"> 
            {isCalculated && (
                <Alert color="success">
                    Salaries calculated successfully for all employees in **{selectedRole}**!
                </Alert>
            )}
            
            <Card className="shadow-lg border-0">
                <CardHeader tag="h4" className="d-flex justify-content-between align-items-center bg-primary text-white">
                    <span className="fw-bold">📅 {selectedRole} Payroll Sheet </span>
                    
                    <div>
                        <Button color="light" onClick={onBack} size="sm" className="me-2">
                             Go Back
                        </Button>
                        <Button 
                            color="warning" 
                            size="sm" 
                            onClick={handleCalculateAllClick}
                            disabled={!employees.length || isCalculated} 
                        >
                           Calculate
                        </Button>
                    </div>
                </CardHeader>
                <div className="p-3">
                    {/* Display message if no employees found for the role */}
                    {!employees.length && (
                        <Alert color="warning">No employees found for this role. Select a different role.</Alert>
                    )}
                    <Table bordered responsive className="mb-0 align-middle">
                        <thead>
                            <tr className="table-light">
                                <th>ID</th>
                                <th>Name</th>
                                <th>Role</th>
                                <th style={{ width: '15%', minWidth: '100px' }}>LOPs (Days)</th>
                                <th style={{ width: '20%', minWidth: '120px' }}>Net Salary</th>
                                <th style={{ width: '10%', minWidth: '80px' }}>Payslip</th>
                            </tr>
                        </thead>
                        <tbody>
                            {employees.map((emp) => {
                                const data = payrollData[emp.empId];
                                const calculated = data && data.netSalary !== undefined && data.netSalary !== null;

                                return (
                                    <tr key={emp.empId}>
                                        <td>{emp.empId}</td>
                                        <td>{emp.name}</td>
                                        <td>{emp.role}</td>
                                        
                                        <td>
                                            <strong className="text-danger">{emp.lopDays || 0}</strong>
                                        </td>
                                        
                                        <td>
                                            <strong className={calculated ? "text-success" : "text-info"}>
                                                {calculated ? data.salaryDisplay : 'N/A'}
                                            </strong>
                                        </td>

                                        <td>
                                            <Button
                                                color="info"
                                                size="sm"
                                                onClick={() => handleGeneratePaySlip(emp.empId)}
                                                disabled={!calculated} 
                                            >
                                                Payslip
                                            </Button>
                                        </td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </Table>
                </div>
            </Card>

            {/* Payslip Modal Component */}
            <PayslipModal
                isOpen={modalOpen}
                toggle={toggleModal}
                employee={employeeForModal}
                payrollData={payrollDataForModal}
            />
        </div>
    );
};

export default EmployeePayrollTable;