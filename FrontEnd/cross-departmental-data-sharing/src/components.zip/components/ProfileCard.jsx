import React from "react";
import {
  Card,
  CardBody,
  CardTitle,
  CardSubtitle,
  CardText,
  Row,
  Col,
  CardFooter,
} from "reactstrap";
const ProfileCard = () => {
  return (
    <div
      className="min-vh-100 d-flex flex-column align-items-center pt-4 pb-4"
      style={{
        backgroundColor: "#b1e6a1",
      }}
      //     backgroundColor: "#36b1d4",
      //     minHeight: "100vh",
      //     display: "flex",
      //     flexDirection: "column",
      //     alignItems: "center",
      //     paddingTop: "20px",
      //     paddingBottom: "20px",
      //   }}
    >
      {/* Main Profile Card */}
      <Card
        xs={3} 
        style={{
          maxWidth: "400px", // Adjusted max-width for a tighter card
          width: "100%",
          borderRadius: "10px",
          boxShadow: "0 4px 15px rgba(0,0,0,0.2)",
          marginTop: "70px", // Space below the header bar
          marginBottom: "20px",
          overflow: "hidden", // Important for rounded corners on inner elements
        }}
      >
        {/* Company Logo at the very top of the card */}
        <div
          className="text-center py-3"
          style={{ borderBottom: "1px solid #eee" }}
        >
          <h4>Company Name</h4>
        </div>

        <CardBody className="text-center pb-0">
          {/* pb-0 to remove bottom padding if card-footer is tight */}
          {/* Employee Image (Center) */}
          <img
            className="rounded-3 mb-3  object-fit-cover border-3  "
            style={{
              width: "120px",
              height: "120px",
            }}
            // }}
            src="/employeeImg.jpeg"
          />

          <CardTitle tag="h4" className="mb-0">
            ABC
          </CardTitle>

          <CardSubtitle className="mb-4 text-muted" tag="h6">
            TSD
          </CardSubtitle>

          <div className="text-left px-3">
            <Row className="mb-2">
              <Col xs={12}>
                <CardText className="font-weight-bold">3245</CardText>
              </Col>
            </Row>

            <hr className="my-3" />

            <Row className="mb-2">
              <Col xs={12}>
                <CardText className="font-weight-bold"></CardText>
              </Col>
            </Row>

            <Row className="align-items-center mb-3">
              <Col xs={6} className="text-left">
                <CardText className="font-weight-bold">9856342109</CardText>
              </Col>
              <Col xs={6} className="text-right">
                <CardText className="text-primary">abc@gmail.com</CardText>
              </Col>
            </Row>
          </div>
        </CardBody>

        {/* Card Footer with Company Domain */}
        <CardFooter className="text-center py-3 bg-light">
          <CardText className="mb-0 text-muted small">www.company.com</CardText>
        </CardFooter>
      </Card>
    </div>
  );
};

export default ProfileCard;
