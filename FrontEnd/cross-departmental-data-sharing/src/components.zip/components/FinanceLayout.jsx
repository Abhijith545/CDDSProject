// FinanceLayout.jsx (UPDATED with FinanceSidebar component)
import React, { useState } from 'react';
import { Container, Row, Col, Button } from 'reactstrap'; // Removed unused Nav, NavItem, NavLink
import { Menu } from 'react-feather'; 
import RoleSelection from './RoleSelection'; 
import EmployeePayrollTable from './EmployeePayrollTable';
import FinanceSidebar from './FinanceSidebar'; // <-- Import the new component


// NOTE: You should ensure your main application CSS (e.g., index.css or App.css) 
// has the following rule applied to remove default browser margin/padding:
/*
html, body, #root {
    margin: 0;
    padding: 0;
    height: 100%;
}
*/

const FinanceLayout = () => {
    const [isSidebarOpen, setIsSidebarOpen] = useState(true);
    const [activeService, setActiveService] = useState('Payroll'); // DEFAULT SELECTED
    const [selectedRole, setSelectedRole] = useState(null); 

    const toggleSidebar = () => setIsSidebarOpen(!isSidebarOpen);
    
    const handleRoleSelect = (role) => {
        setSelectedRole(role);
    };
    
    const handleBackToRoles = () => {
        setSelectedRole(null);
    };

    const renderContent = () => {
        if (activeService === 'Payroll') {
            if (!selectedRole) {
                return <RoleSelection onRoleSelect={handleRoleSelect} />;
            } else {
                return (
                    <div className="flex-grow-1 p-3">
                        <EmployeePayrollTable 
                            selectedRole={selectedRole} 
                            onBack={handleBackToRoles}
                        />
                    </div>
                );
            }
        } 
    
        return <p className="p-4 text-muted">Content for {activeService} service goes here.</p>;
    };

    return (
        <Container 
            fluid 
            className="vh-100 d-flex flex-column" 
            style={{ 
                paddingLeft: 0, 
                paddingRight: 0 
            }}
        >
           
         
            
            {/* Main Content and Sidebar Row (takes up remaining space) */}
            <Row noGutters className="flex-grow-1">
                {/* --- 1. Sidebar Column --- */}
                {isSidebarOpen && (
                    <Col xs="auto">
                        <FinanceSidebar 
                            activeService={activeService}
                            setActiveService={setActiveService}
                            setSelectedRole={setSelectedRole} // Pass setter to reset role on service change
                        />
                    </Col>
                )}

                {/* --- 2. Main Content Column --- */}
                <Col 
                    className="content-area flex-grow-1 " 
                    style={{ overflowY: 'auto' }}
                >
                    {renderContent()}
                </Col>
            </Row>
        </Container>
    );
};

export default FinanceLayout;