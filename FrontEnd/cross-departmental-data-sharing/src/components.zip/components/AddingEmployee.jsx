import React from "react";
import {
  Form,
  Row,
  Col,
  FormGroup,
  Label,
  Input,
  Button,
  Card,
  CardBody,
  CardHeader,
  FormFeedback,
} from "reactstrap";
import { Formik } from "formik";
import * as Yup from "yup";

export function AddingEmployee() {
  const initialValues = {
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    dob: "",
    gender: "",
    address: "",
    join_date: "",
    department_name: "",
    designation: "",
    employee_type: "",
    manager_id: "",
  };

  const validationSchema = Yup.object({
    firstName: Yup.string().required("First Name is required"),
    lastName: Yup.string().required("Last Name is required"),
    email: Yup.string().email("Invalid email").required("Email is required"),
    phone: Yup.string()
      .matches(/^\d+$/, "Phone must be numeric")
      .length(10, "phone number must contain 10 digits")
      .required("Phone is required"),
    dob: Yup.date().required("Date of Birth is required"),
    gender: Yup.string().required("Gender is required"),
    address: Yup.string().required("Address is required"),
    join_date: Yup.date().required("Join Date is required"),
    department_name: Yup.string().required("Department is required"),
    designation: Yup.string().required("Designation is required"),
    employee_type: Yup.string().required("Employment Type is required"),
    manager_id: Yup.number()
      .typeError("Manager ID must be a number")
      .required("Manager ID is required"),
  });

  const handleSubmit = (values) => {
    console.log("Form Submitted:", values);
    alert("Form Submitted! Check console for details.");
  };

  return (
    <div className="container mt-4">
      <Card>
        <CardHeader>
          <h2 className="text-center mb-0">Employee Form</h2>
        </CardHeader>
        <CardBody>
          <Formik
            initialValues={initialValues}
            validationSchema={validationSchema}
            onSubmit={handleSubmit}
          >
            {({
              values,
              errors,
              touched,
              handleChange,
              handleBlur,
              handleSubmit,
              setFieldValue,
            }) => (
              <Form onSubmit={handleSubmit}>
                {/* FIRST + LAST NAME */}
                <Row>
                  <Col md={6}>
                    <FormGroup>
                      <Label for="firstName">First Name</Label>
                      <Input
                        id="firstName"
                        name="firstName"
                        placeholder="Enter First Name"
                        type="text"
                        value={values.firstName}
                        onChange={handleChange}
                        
                        invalid={touched.firstName && !!errors.firstName}
                      />
                      <FormFeedback>{errors.firstName}</FormFeedback>
                    </FormGroup>
                  </Col>
                  <Col md={6}>
                    <FormGroup>
                      <Label for="lastName">Last Name</Label>
                      <Input
                        id="lastName"
                        name="lastName"
                        placeholder="Enter Last Name"
                        type="text"
                        value={values.lastName}
                        onChange={handleChange}
                        invalid={touched.lastName && !!errors.lastName}
                      />
                      <FormFeedback>{errors.lastName}</FormFeedback>
                    </FormGroup>
                  </Col>
                </Row>

                {/* EMAIL + PHONE + DOB */}
                <Row>
                  <Col md={4}>
                    <FormGroup>
                      <Label for="email">Email</Label>
                      <Input
                        id="email"
                        name="email"
                        placeholder="Enter Email"
                        type="email"
                        value={values.email}
                        onChange={handleChange}
                        invalid={touched.email && !!errors.email}
                      />
                      <FormFeedback>{errors.email}</FormFeedback>
                    </FormGroup>
                  </Col>
                  <Col md={4}>
                    <FormGroup>
                      <Label for="phone">Phone</Label>
                      <Input
                        id="phone"
                        name="phone"
                        placeholder="Enter Phone Number"
                        type="tel"
                        value={values.phone}
                        onChange={handleChange}
                        invalid={touched.phone && !!errors.phone}
                      />
                      <FormFeedback>{errors.phone}</FormFeedback>
                    </FormGroup>
                  </Col>
                  <Col md={4}>
                    <FormGroup>
                      <Label for="dob">Date of Birth</Label>
                      <Input
                        id="dob"
                        name="dob"
                        type="date"
                        value={values.dob}
                        onChange={handleChange}
                        invalid={touched.dob && !!errors.dob}
                      />
                      <FormFeedback>{errors.dob}</FormFeedback>
                    </FormGroup>
                  </Col>
                </Row>

                {/* GENDER */}
                <Row>
                  <Col md={6}>
                    <FormGroup>
                      <Label className="d-block">Gender</Label>
                      <FormGroup check inline>
                        <Input
                          type="radio"
                          id="genderMale"
                          name="gender"
                          value="Male"
                          checked={values.gender === "Male"}
                          onChange={handleChange}
                        />
                        <Label check for="genderMale">
                          Male
                        </Label>
                      </FormGroup>
                      <FormGroup check inline>
                        <Input
                          type="radio"
                          id="genderFemale"
                          name="gender"
                          value="Female"
                          checked={values.gender === "Female"}
                          onChange={handleChange}
                        />
                        <Label check for="genderFemale">
                          Female
                        </Label>
                      </FormGroup>
                      {touched.gender && errors.gender && (
                        <div className="text-danger">{errors.gender}</div>
                      )}
                    </FormGroup>
                  </Col>
                </Row>

                {/* ADDRESS */}
                <FormGroup>
                  <Label for="address">Address</Label>
                  <Input
                    id="address"
                    name="address"
                    type="textarea"
                    placeholder="Enter full address"
                    value={values.address}
                    onChange={handleChange}
                    // onBlur={handleBlur}
                    invalid={touched.address && !!errors.address}
                  />
                  <FormFeedback>{errors.address}</FormFeedback>
                </FormGroup>

                {/* JOIN DATE + DEPARTMENT */}
                <Row>
                  <Col md={6}>
                    <FormGroup>
                      <Label for="join_date">Join Date</Label>
                      <Input
                        id="join_date"
                        name="join_date"
                        type="date"
                        value={values.join_date}
                        onChange={handleChange}
                        invalid={touched.join_date && !!errors.join_date}
                      />
                      <FormFeedback>{errors.join_date}</FormFeedback>
                    </FormGroup>
                  </Col>
                  <Col md={6}>
                    <FormGroup>
                      <Label for="department_name">Department</Label>
                      <Input
                        id="department_name"
                        name="department_name"
                        type="select"
                        value={values.department_name}
                        onChange={handleChange}
                        invalid={
                          touched.department_name && !!errors.department_name
                        }
                      >
                        <option value="" disabled selected>
                          Select Department
                        </option>
                        <option value="HR">HR</option>
                        <option value="Finance">Finance</option>
                        <option value="Health">Health</option>
                      </Input>
                      <FormFeedback>{errors.department_name}</FormFeedback>
                    </FormGroup>
                  </Col>
                </Row>

                {/* DESIGNATION + EMPLOYMENT TYPE */}
                <Row>
                  <Col md={6}>
                    <FormGroup>
                      <Label for="designation">Designation</Label>
                      <Input
                        id="designation"
                        name="designation"
                        type="select"
                        value={values.designation}
                        onChange={handleChange}
                        invalid={touched.designation && !!errors.designation}
                      >
                        <option value="" disabled selected>
                          Select Designation
                        </option>
                        <option value="Project Manager">Project Manager</option>
                        <option value="Software Developer">
                          Software Developer
                        </option>
                        <option value="Senior Software Developer">
                          Senior Software Developer
                        </option>
                        <option value="Team Lead">Team Lead</option>
                        <option value="Trainee Software Developer">
                          Trainee Software Developer
                        </option>
                      </Input>
                      <FormFeedback>{errors.designation}</FormFeedback>
                    </FormGroup>
                  </Col>

                  <Col md={6}>
                    <FormGroup>
                      <Label for="employee_type">Employment Type</Label>
                      <Input
                        id="employee_type"
                        name="employee_type"
                        type="select"
                        value={values.employee_type}
                        onChange={handleChange}
                        invalid={
                          touched.employee_type && !!errors.employee_type
                        }
                      >
                        <option value="" disabled selected>
                          Select Type
                        </option>
                        <option value="Full Time">Full Time</option>
                        <option value="Part Time">Part Time</option>
                        <option value="Contract">Contract</option>
                      </Input>
                      <FormFeedback>{errors.employee_type}</FormFeedback>
                    </FormGroup>
                  </Col>
                </Row>

                {/* MANAGER ID */}
                <FormGroup>
                  <Label for="manager_id">Manager ID</Label>
                  <Input
                    id="manager_id"
                    name="manager_id"
                    placeholder="Enter Manager ID"
                    type="number"
                    value={values.manager_id}
                    onChange={handleChange}
                    invalid={touched.manager_id && !!errors.manager_id}
                  />
                  <FormFeedback>{errors.manager_id}</FormFeedback>
                </FormGroup>

                <FormGroup className="text-center">
                  <Button color="primary" type="submit" className="mt-3">
                    Submit
                  </Button>
                </FormGroup>
              </Form>
            )}
          </Formik>
        </CardBody>
      </Card>
    </div>
  );
}
