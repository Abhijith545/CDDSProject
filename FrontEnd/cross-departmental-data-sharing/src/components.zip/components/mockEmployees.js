// mockEmployees.js

// Using Annual Base Salaries for calculation simplicity
export const mockEmployees = {
 TSD: [
  { empId: 'T001', name: 'Alice Smith', role: 'TSD', baseSalary: 720000, lopDays: 0 }, // 0 LOP
  { empId: 'T002', name: 'Bob Johnson', role: 'TSD', baseSalary: 744000, lopDays: 1 }, // 1 LOP
 ],
 SD: [
  { empId: 'S001', name: 'David Lee', role: 'SD', baseSalary: 1020000, lopDays: 2 }, // 2 LOPs
  { empId: 'S002', name: 'Eva Green', role: 'SD', baseSalary: 1056000, lopDays: 0 }, // 0 LOP
 ],
 PM: [
  { empId: 'P001', name: 'Frank White', role: 'PM', baseSalary: 1440000, lopDays: 3 }, // 3 LOPs
  { empId: 'P002', name: 'Grace Hall', role: 'PM', baseSalary: 1500000, lopDays: 1 }, // 1 LOP
 ],
 PL: [
  { empId: 'L001', name: 'Henry Ford', role: 'PL', baseSalary: 1800000, lopDays: 0 }, // 0 LOP
 ],
 TM: [
  { empId: 'M001', name: 'Ivy Stone', role: 'TM', baseSalary: 1140000, lopDays: 5 }, // 5 LOPs
 ],
};