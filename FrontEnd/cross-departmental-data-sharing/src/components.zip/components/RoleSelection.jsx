// RoleSelection.jsx
import React from 'react';
import { Card, CardBody, CardTitle, Button, Container, Row, Col } from 'reactstrap';
import { mockEmployees } from './mockEmployees';

const RoleSelection = ({ onRoleSelect }) => {
    const roles = Object.keys(mockEmployees);

    return (
        <Container fluid className="p-4">
            <h2 className="mb-4 text-primary">Select Payroll Role</h2>
            
            <Row className="g-3 justify-content-start">
                {roles.map(role => (
                    <Col 
                        xs="12" // Full width on extra-small screens (1 card per row)
                        sm="6"  // Half width on small screens (2 cards per row)
                        md="4"  // 4 columns on medium screens (3 cards per row)
                        lg="4"  // 4 columns on large screens (3 cards per row)
                        key={role}
                        // Custom style removed to rely entirely on Bootstrap grid sizing
                    >
                        {/* Shadow-lg and h-100 retained for visual appeal and uniform height */}
                        <Card className="shadow-lg h-170 border-0"> 
                            <CardBody className="d-flex flex-column justify-content-between">
                                <CardTitle tag="h5" className="fw-bold text-center text-secondary">{role}</CardTitle>
                                <p className="text-muted text-center">
                                    Employees: {mockEmployees[role].length}
                                </p>
                                <Button 
                                    color="primary" 
                                    block // makes the button full width
                                    onClick={() => onRoleSelect(role)}
                                >
                                    View Payroll
                                </Button>
                            </CardBody>
                        </Card>
                    </Col>
                ))}
            </Row>
        </Container>
    );
};

export default RoleSelection;