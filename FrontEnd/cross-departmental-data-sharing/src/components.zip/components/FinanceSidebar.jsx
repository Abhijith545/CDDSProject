// FinanceLayout.jsx
import React, { useState } from 'react';
import { Container, Row, Col, Button } from 'reactstrap';
import { Menu } from 'react-feather'; 
import RoleSelection from './RoleSelection'; 
import EmployeePayrollTable from './EmployeePayrollTable';
import FinanceSidebar from './FinanceSidebar'; 

// NOTE: You should ensure your main application CSS (e.g., index.css or App.css) 
// has the following rule applied to remove default browser margin/padding:
/*
html, body, #root {
    margin: 0;
    padding: 0;
    height: 100%;
}
*/

const FinanceLayout = () => {
    const [isSidebarOpen, setIsSidebarOpen] = useState(true);
    const [activeService, setActiveService] = useState('Payroll'); 
    const [selectedRole, setSelectedRole] = useState(null); 

    const toggleSidebar = () => setIsSidebarOpen(!isSidebarOpen);
    
    const handleRoleSelect = (role) => {
        setSelectedRole(role);
    };
    
    const handleBackToRoles = () => {
        setSelectedRole(null);
    };

    const renderContent = () => {
        if (activeService === 'Payroll') {
            if (!selectedRole) {
                return <RoleSelection onRoleSelect={handleRoleSelect} />;
            } else {
                return (
                    <div className="flex-grow-1 p-3">
                        <EmployeePayrollTable 
                            selectedRole={selectedRole} 
                            onBack={handleBackToRoles}
                        />
                    </div>
                );
            }
        } 
        return <p className="p-4 text-muted">Content for {activeService} service goes here.</p>;
    };

    return (
        <Container 
            fluid 
            className="vh-100 d-flex flex-column" 
            style={{ 
                padding: 0, // Ensure no padding on the main container
            }}
        >
            {/* --- 0. Header/Toggle Bar --- */}
            <header className="bg-light p-2 border-bottom d-flex align-items-center">
                <Button color="link" onClick={toggleSidebar} className="me-3">
                    <Menu size={24} />
                </Button>
                <h4 className="m-0 text-dark">Finance Dashboard</h4>
            </header>
            
            {/* Main Content and Sidebar Row (takes up remaining space) */}
            <Row noGutters className="flex-grow-1">
                {/* --- 1. Sidebar Column --- */}
                {isSidebarOpen && (
                    <Col xs="auto">
                        <FinanceSidebar 
                            activeService={activeService}
                            setActiveService={setActiveService}
                            setSelectedRole={setSelectedRole} 
                        />
                    </Col>
                )}

                {/* --- 2. Main Content Column --- */}
                <Col 
                    className="content-area" // Removed flex-grow-1 from Col; Row handles the flex grow
                    style={{ 
                        overflowY: 'auto',
                        // Removed width: 100% and rely on flex behavior
                    }}
                >
                    {renderContent()}
                </Col>
            </Row>
        </Container>
    );
};

export default FinanceLayout;